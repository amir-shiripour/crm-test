@extends('layouts.app')

@section('content')
<div class="container mx-auto p-4">
  <h1 class="text-2xl font-bold">Customers</h1>
  <div id="customers-root">
    <!-- Blade + Tailwind list placeholder -->
    <p class="text-gray-600">This is a placeholder customer list. Replace with real component or integrate React widget here.</p>
  </div>
</div>
@endsection

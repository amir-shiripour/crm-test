<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-4">
  <h1 class="text-2xl font-bold">Customers</h1>
  <div id="customers-root">
    <!-- Blade + Tailwind list placeholder -->
    <p class="text-gray-600">This is a placeholder customer list. Replace with real component or integrate React widget here.</p>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Web\laragon\www\my-crm\backend\modules\Customer\Providers/../Resources/views/index.blade.php ENDPATH**/ ?>